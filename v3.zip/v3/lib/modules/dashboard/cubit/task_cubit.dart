import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:todoapp_brainmentors/modules/dashboard/services/task_crud.dart';

import 'task_state.dart';

class TaskCubit extends Cubit<DBStates> {
  TaskCrud _taskCrud = TaskCrud();
  DocumentSnapshot? _lastDocument;
  bool _hasMoreRecords = true;
  TaskCubit() : super(TaskState()) {
    getCount();
  }
  updateTaskStatus(id, status) async {
    await _taskCrud.updateTaskStatus(id, status);
    //emit(TaskState.setMessage("Task Status Updated..."));
  }

  addNewTask(String taskName, String taskDesc, String location) async {
    var doc = await _taskCrud.addNewTask(taskName, taskDesc, location);
    print("Doc is ");
    print(doc);
    emit(TaskState.init(1, "A", "B", "C"));
  }

  getCount() async {
    int count = await _taskCrud.getCountTask();
    int completedCount = await _taskCrud.getCountCompletedTask();
    emit(TaskState.initCount(count, completedCount));
  }

  Future<void> getAllTasks(String? searchQuery, String? sortBy) async {
    // Loading State
    emit(LoadingState());
    int count = await _taskCrud.getCountTask();
    int completedCount = await _taskCrud.getCountCompletedTask();
    try {
      // Completed State
      QuerySnapshot<Map<String, dynamic>> snapShot =
          await _taskCrud.getAllTasks(searchQuery, sortBy, _lastDocument);
      print("############Snap shot....... ${snapShot.docs.length}");
      if (snapShot.docs.isNotEmpty) {
        _lastDocument = snapShot.docs.last;
        _hasMoreRecords = (snapShot.docs.length == 10);
        print("Emit Happends. ${snapShot.docs.length}");

        emit(TaskState.fillTasks(
            snapShot.docs, _hasMoreRecords, count, completedCount));
      } else {
        _hasMoreRecords = false;
        emit(TaskState.fillTasks([], _hasMoreRecords, count, completedCount));
      }
    } catch (err) {
      // Error State
      emit(ErrorState());
    }
  }

  resetPagination() {
    _lastDocument = null;
    _hasMoreRecords = true;
  }
}
