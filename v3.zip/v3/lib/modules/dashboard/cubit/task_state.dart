import 'package:cloud_firestore/cloud_firestore.dart';

class TaskState extends DBStates {
  late int id = 0;
  late String name = "";
  late String desc = "";
  late String location = "";
  String message = "";
  int? count;
  int? completedCount;
  List<DocumentSnapshot>? records;
  bool? hasMoreRecords;
  TaskState() {
    id = 0;
    name = "";
    desc = "";
    location = "";
    count = 0;
    completedCount = 0;
  }
  TaskState.init(this.id, this.name, this.desc, this.location);
  TaskState.initCount(this.count, this.completedCount);
  TaskState.fillTasks(
      this.records, this.hasMoreRecords, this.count, this.completedCount);

  @override
  List get props => [records, hasMoreRecords, count];
}

class LoadingState extends DBStates {}

class ErrorState extends DBStates {}

abstract class DBStates {
  List get props => [];
}
