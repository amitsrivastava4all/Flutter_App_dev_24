import 'package:cloud_firestore/cloud_firestore.dart';

class TaskCrud {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  addNewTask(String taskName, String taskDesc, String location) async {
    DocumentReference _doc = await _firestore.collection('tasks').add({
      'name': taskName,
      'desc': taskDesc,
      'location': location,
      'status': false // Pending Status
    });
    return _doc;
  }

  updateTaskStatus(id, status) async {
    await _firestore.collection('tasks').doc(id).update({'status': !status});
  }

  Future<int> getCountTask() async {
    QuerySnapshot snapshot = await _firestore.collection('tasks').get();
    return snapshot.docs.length;
  }

  Future<int> getCountCompletedTask() async {
    QuerySnapshot snapshot = await _firestore
        .collection('tasks')
        .where('status', isEqualTo: true)
        .get();
    print("Total Completed....... ${snapshot.docs.length}");
    return snapshot.docs.length;
  }

  Future<QuerySnapshot<Map<String, dynamic>>> getAllTasks(String? searchQuery,
      String? sortBy, DocumentSnapshot? lastDocument) async {
    print("Last Document $lastDocument");
    print("Sort By $sortBy");
    Query<Map<String, dynamic>> query = _firestore.collection('tasks');
    // add the search criteria
    if (searchQuery != null) {
      print("Search Query $searchQuery");
      query = query.where('name', isEqualTo: searchQuery);
    }

    // add the sort feature
    if (sortBy != null) {
      print("Doing Sort $sortBy");
      query = query.orderBy(sortBy, descending: false);
    }
    if (lastDocument != null) {
      query = query.startAfterDocument(lastDocument);
    }

    // record comes in paginated way
    return await query.limit(10).get();
  }
}
