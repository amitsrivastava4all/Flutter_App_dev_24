import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:todoapp_brainmentors/modules/dashboard/cubit/task_cubit.dart';
import 'package:todoapp_brainmentors/modules/dashboard/cubit/task_state.dart';

class AllTasks extends StatefulWidget {
  @override
  State<AllTasks> createState() => _AllTasksState();
}

class _AllTasksState extends State<AllTasks> {
  ScrollController _scroll = ScrollController();
  bool isCompleted = false;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _scroll.addListener(_doingScroll);
    BlocProvider.of<TaskCubit>(context).getAllTasks(null, null);
  }

  void _doingScroll() {
    bool reachToBottom = _scroll.position.pixels == 0;
    if (!reachToBottom) {
      BlocProvider.of<TaskCubit>(context).getAllTasks(null, null);
    }
  }

  _update(id, status) async {
    // Look up this id on firebase and then change it flag
    BlocProvider.of<TaskCubit>(context).updateTaskStatus(id, status);
    Fluttertoast.showToast(
        msg: "Task Status Updated...",
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.CENTER,
        timeInSecForIosWeb: 1,
        backgroundColor: Colors.red,
        textColor: Colors.white,
        fontSize: 16.0);
    BlocProvider.of<TaskCubit>(context).resetPagination();
    BlocProvider.of<TaskCubit>(context).getAllTasks(null, null);
    print("Id is ........... " + id + " Status   $status");
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<TaskCubit, DBStates>(builder: (_, state) {
      if (state is ErrorState) {
        return Text(
          'OOPS Something Went Wrong..',
          style: GoogleFonts.aBeeZee(color: Colors.red, fontSize: 20),
        );
      } else if (state is TaskState) {
        //print("State is ");
        //print(state.records?.length);
        return ListView.builder(
          controller: _scroll,
          itemCount: state.records?.length,
          itemBuilder: (_, index) {
            return ListTile(
              title: Text(state.records![index]['name']),
              subtitle: Text(state.records![index]['desc']),
              trailing: Switch(
                  value: state.records![index]['status'],
                  onChanged: (val) {
                    _update(state.records![index].id,
                        state.records![index]['status']);
                  }),
            );
          },
        );
      } else {
        return Center(child: CircularProgressIndicator());
      }
    });
  }
}
