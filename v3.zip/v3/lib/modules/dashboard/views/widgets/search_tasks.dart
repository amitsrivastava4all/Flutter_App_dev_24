import 'dart:async';

import 'package:avatar_glow/avatar_glow.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:speech_to_text/speech_to_text.dart';
import 'package:todoapp_brainmentors/modules/dashboard/cubit/task_cubit.dart';
import 'package:todoapp_brainmentors/modules/dashboard/views/widgets/all_tasks.dart';

class SearchTasks extends StatefulWidget {
  const SearchTasks({super.key});

  @override
  State<SearchTasks> createState() => _SearchTasksState();
}

class _SearchTasksState extends State<SearchTasks> {
  Color _color = Colors.lightBlueAccent;
  int colorCounter = 0;
  Timer? timer;
  _doBackgroundAnimation() {
    timer = Timer.periodic(Duration(seconds: 2), (t) {
      setState(() {
        colorCounter++;
        print(colorCounter);
        switch (colorCounter) {
          case 1:
            _color = Colors.lightGreenAccent;
            break;
          case 2:
            _color = Colors.red.shade50;
            break;
          case 3:
            _color = Colors.pink.shade100;
            break;
          default:
            colorCounter = 0;
        }
      });
    });
  }

  @override
  void dispose() {
    timer?.cancel();

    super.dispose();
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _doBackgroundAnimation();
    BlocProvider.of<TaskCubit>(context).resetPagination();
  }

  SpeechToText _speech = SpeechToText();
  bool isListing = false;
  bool isSwitch = false;
  String words = "";
  void listen() async {
    if (!isListing) {
      bool avaliable = await _speech.initialize(onStatus: (val) {
        print("Success $val");
      }, onError: (err) {
        print("Speech Initalize Error $err");
      });
      print("AV $avaliable");
      if (avaliable) {
        setState(() {
          isListing = true;
          _speech.listen(onResult: (val) {
            setState(() {
              words = val.recognizedWords;
              if (words.length > 3) {
                BlocProvider.of<TaskCubit>(context).resetPagination();
                BlocProvider.of<TaskCubit>(context).getAllTasks(words, null);
                print("Words are $words");
              }
            });
          });
        });
      } else {
        setState(() {
          isListing = false;
          _speech.stop();
        });
      }
    } else {
      setState(() {
        isListing = false;
        _speech.stop();
      });
    }
  }

  _speakNow() {
    listen();
  }

  _doSort() {
    BlocProvider.of<TaskCubit>(context).resetPagination();
    BlocProvider.of<TaskCubit>(context)
        .getAllTasks(null, isSwitch ? "name" : null);
  }

  @override
  Widget build(BuildContext context) {
    // print("Re Build");
    Size size = MediaQuery.of(context).size;
    return AnimatedContainer(
      child: Column(
        children: [
          Container(
            child: AvatarGlow(
              startDelay: const Duration(milliseconds: 1000),
              glowColor: Colors.white,
              glowShape: BoxShape.circle,
              animate: true,
              curve: Curves.fastOutSlowIn,
              child: Material(
                elevation: 8.0,
                shape: CircleBorder(),
                color: Colors.transparent,
                child: InkWell(
                  onTap: () {
                    print("Click Happen");
                    _speakNow();
                  },
                  child: CircleAvatar(
                    backgroundImage: NetworkImage(
                        'https://cdn-icons-png.flaticon.com/256/8135/8135628.png'),
                    radius: 50.0,
                  ),
                ),
              ),
            ),
          ),
          Text(
            'Search Text $words',
            style: GoogleFonts.aBeeZee(fontSize: 14),
          ),
          Container(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text('Sort'),
                Switch(
                  activeColor: Colors.blue,
                  inactiveThumbColor: Colors.black,
                  value: isSwitch,
                  onChanged: (isOn) {
                    setState(() {
                      isSwitch = !isSwitch;
                      _doSort();
                    });
                  },
                ),
              ],
            ),
          ),
          Container(
            color: Colors.yellow.shade50,
            height: size.height * 0.74,
            child: AllTasks(),
            //child: Text('All records print here'),
          )
        ],
      ),
      duration: Duration(seconds: 2),
      color: _color,
      curve: Curves.fastOutSlowIn,
      height: size.height,
      width: size.width,
    );
  }
}
