// DO NOT EDIT. This is code generated via package:easy_localization/generate.dart

abstract class  LocaleKeys {
  static const loginscreen = 'loginscreen';
  static const logingooglebutton = 'logingooglebutton';
  static const loginfacebookbutton = 'loginfacebookbutton';
  static const splashmessage = 'splashmessage';

}
