import 'package:flutter/material.dart';
import './splash.dart';

void main() {
  runApp(MaterialApp(
    title: 'ToDo App',
    home: Splash(),
  ));
}
